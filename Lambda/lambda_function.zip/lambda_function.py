import boto3
 
cloudwatch_client = boto3.client('cloudwatch')
 
def lambda_handler(event, context):
    instance_ids = get_reporting_ec2_instance_ids()
 
    for instance_id in instance_ids:
        if not check_existing_alarms(instance_id):
            create_default_alarms(instance_id)
 
    return {
        'statusCode': 200,
        'body': 'Lambda execution completed.'
    }
 
def get_reporting_ec2_instance_ids():
    metrics = cloudwatch_client.list_metrics(Namespace='AWS/EC2', MetricName='CPUUtilization')
    instance_ids = set()
    for metric in metrics['Metrics']:
        for dimension in metric['Dimensions']:
            if dimension['Name'] == 'InstanceId':
                instance_ids.add(dimension['Value'])
    return list(instance_ids)
 
def check_existing_alarms(instance_id):
    response = cloudwatch_client.describe_alarms(AlarmNamePrefix=f'EC2-{instance_id}')
    return len(response['MetricAlarms']) > 0
 
def create_default_alarms(instance_id):
    create_cpu_utilization_alarm(instance_id)
 
def create_cpu_utilization_alarm(instance_id):
    cloudwatch_client.put_metric_alarm(
        AlarmName=f'EC2-{instance_id}-High-CPU-Utilization',
        AlarmDescription='Alarm when CPU exceeds 80%',
        ActionsEnabled=True,
        MetricName='CPUUtilization',
        Namespace='AWS/EC2',
        Statistic='Average',
        Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
        Period=300,
        EvaluationPeriods=1,
        Threshold=80.0,
        ComparisonOperator='GreaterThanThreshold',
        AlarmActions=[os.environ['SNS_TOPIC_ARN']]
    )